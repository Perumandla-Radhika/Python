#sorted
s={1, 1, 2, 2, 3, 3, 5, 7, 7, 5}
print(sorted(s))
# to get output in set
set(sorted(s))
print(s)