#program to calculate the length of a string

a="cheryy cherry"
print(len(a))

#another method
def len1(str):
    count=0
    for char in str1:
        count +=1
    return count
str1=input()
print(len1(str1))
