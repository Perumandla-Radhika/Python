print('hello'.endswith('o'))
print('hello'.startswith('h'))
print('hello'.replace('l', 't'))
print('100'.isdigit())
print('abc'.isalpha())
print('72'.isdecimal())
print('ab12'.isalnum())
print('Hello World'.istitle())
print('hello'.upper())
print('hello'.lower())
print('hello'.swapcase())

str="shanks is my nickname"
print(str.partition("is"))