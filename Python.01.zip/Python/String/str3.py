str2 = """hi
this 
is sash"""
print(str2.splitlines())

str="charitha"
print(str.index('a'))
print(str.rindex('a')) #last index of a

print('python programming'.capitalize())
print('python cython'.find('th'))
print('pytho cython'.rfind('th'))
print('python cython'.count('th'))

