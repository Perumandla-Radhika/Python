#python script that takes input from the user and displays that input back in upper and lower cases

s="My car is BmW"
s2="BmW"
s3=s.replace(s2,s2.upper())
print(s3)

