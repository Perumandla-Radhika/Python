a = "Revathi"
print(len(a))
print(max(a))
print(min(a))
print(a*2)