n=int(input())
for i in range(1,11):
    print(n,"*",i,"=",n*i)