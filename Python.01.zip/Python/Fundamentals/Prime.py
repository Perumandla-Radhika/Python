n= int(input())
