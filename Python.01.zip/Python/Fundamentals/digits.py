num = int(input())
count = 0
while num!=0:
    num //=10
    count +=1
print("No.of digits:", count)

#float division num=num//10