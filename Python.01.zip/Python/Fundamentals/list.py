#list is a mutable datatype.
L=[12,5.67,'hi',98]
L[0]=43.7
#list can be deleted
del L['hi']
print(L)