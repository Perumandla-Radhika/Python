a=float(input())
#for nearest number
print(round(a))
#for 2 decimal numbers
print(round(a,2))
#for nearest 10's digit
print(round(a,-1))
#for nearest 100's digit
print(round(a,-2))