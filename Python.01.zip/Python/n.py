n=4
x=0
for i in range(3,n+1):
    x=x^i
print(x)

#alternative by taking input from user
a=int(input())
b=int(input())
x=0
for i in range(a,b+1):
    x=x^i
print(x)