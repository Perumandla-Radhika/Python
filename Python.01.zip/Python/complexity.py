N=int(input())
if(N%4 == 1):
    print(1)
elif(N%4==2):
    print(N+1)
elif(N%4==3):
    print(0)
elif(N%4==0):
    print(N)